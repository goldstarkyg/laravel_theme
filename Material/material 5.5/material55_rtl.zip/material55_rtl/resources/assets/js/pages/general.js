$.material.init();
$('.progress .progress-bar').progressbar({display_text: 'center'});