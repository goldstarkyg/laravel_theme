var base = require('settings/api');

Vue.component('spark-api', {
    mixins: [base]
});
