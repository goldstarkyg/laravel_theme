var base = require('settings/teams/team-profile');

Vue.component('spark-team-profile', {
    mixins: [base]
});
