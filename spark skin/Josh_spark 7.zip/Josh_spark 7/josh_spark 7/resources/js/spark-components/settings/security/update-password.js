var base = require('settings/security/update-password');

Vue.component('spark-update-password', {
    mixins: [base]
});
