var base = require('settings/teams/update-team-photo');

Vue.component('spark-update-team-photo', {
    mixins: [base]
});
