var base = require('auth/register-braintree');

Vue.component('spark-register-braintree', {
    mixins: [base]
});
