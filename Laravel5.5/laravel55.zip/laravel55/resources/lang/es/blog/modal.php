<?php

/**
* Language file for blog delete modal
*
*/
return array(

    'body'			=> 'Está seguro que quiere borrar este blog? Esto es irreversible.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Borrar',
    'title'         => 'Borra Blog',

);
