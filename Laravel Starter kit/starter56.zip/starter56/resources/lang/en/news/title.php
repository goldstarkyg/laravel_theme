<?php
/**
 * Language file for blog section titles
 *
 */

return array(

    'title' => 'Title',
    'create' => 'Create News',
    'edit' => 'Edit News',
    'add-news' => 'Add News',
    'news' => 'News',
    'newslist' => 'News List',
    'newsdetail' => 'News Details',


);
