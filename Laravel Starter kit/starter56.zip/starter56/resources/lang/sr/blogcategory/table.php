<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Redni br.',
    'name'       => 'Naziv',
    'blogs'      => 'Br. blogova',
    'created_at' => 'Kreirano',
    'actions'	 => 'Akcije',

);
