<?php

/**
* Language file for blog delete modal
*
*/
return array(

    'body'			=> 'Da lis te sigurni da �elite obrisati ovu blog kategoriju? Nakon ove operacije nije mogu?e vratiti podatke.',
    'cancel'		=> 'Odustani',
    'confirm'		=> 'Obri�i',
    'title'         => 'Obri�i blog kategoriju',

);
