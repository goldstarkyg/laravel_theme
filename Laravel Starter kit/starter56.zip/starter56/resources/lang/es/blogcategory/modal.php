<?php

/**
* Language file for blog delete modal
*
*/
return array(

    'body'			=> 'Está seguro que quiere borrar esta categoria del blog? Esto es irreversible.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Borrar',
    'title'         => 'Borrar Categoría del Blog',

);
