<?php

/**
* Language file for blog delete modal
*
*/
return array(

    'body'			=> 'Êtes-vous sûr de vouloir supprimer cette catégorie de blog ? Cette opération est irréverssible.',
    'cancel'		=> 'Annuler',
    'confirm'		=> 'Supprimer',
    'title'         => 'Supprimer la catégorie de blog',

);
