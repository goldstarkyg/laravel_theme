<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Groep naam',
    'slug'          => 'Slug',
    'general' 		=> 'Algemeen',
    'permissions'	=> 'Machtigingen',

);
