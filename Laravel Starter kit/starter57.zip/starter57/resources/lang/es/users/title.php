<?php
/**
* Language file for user section titles
*
*/

return array(

	'user_profile'			=> 'Perfil de Usuario',
	'first_name'			=> 'Nombre',
	'last_name'				=> 'Apellido',
	'email'					=> 'E-mail',
	'phone'					=> 'Número de Teléfono',
	'address'				=> 'Dirección',
	'city'					=> 'Ciudad',
	'status'				=> 'Estado',
	'created_at'			=> 'Creado el',
    'select_image'			=> 'Seleccionar Imágen',
    'gender'				=> 'Sexo',
    'dob'					=> 'Fecha de Nacimiento',
    'country'				=> 'País',
    'state'					=> 'Estado',
    'postal'				=> 'Código Postal'
    
);
