<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Naziv grupe',
    'general' 		=> 'Op�te',
    'permissions'	=> 'Permisije',

);
