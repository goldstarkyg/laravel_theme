<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Nombre',
    'blogs'      => 'N° de Blogs',
    'created_at' => 'Creado el ',
    'actions'	 => 'Acciones',

);
