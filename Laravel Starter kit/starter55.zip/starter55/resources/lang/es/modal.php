<?php

/**
 * Language file for delete modal
 *
 */
return array(

    'title'         => 'Borrar registro',
    'body'			=> 'Está seguro que quiere borrar este registro? Esto es irreversible.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Borrar',

);
