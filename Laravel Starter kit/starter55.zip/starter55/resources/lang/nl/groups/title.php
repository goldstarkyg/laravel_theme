<?php
/**
* Language file for group section titles
*
*/

return array(

    'create'			=> 'Maak een nieuwe groep',
    'edit' 				=> 'Wijzig groep',
    'management'	=> 'Beheer groepen',

);
